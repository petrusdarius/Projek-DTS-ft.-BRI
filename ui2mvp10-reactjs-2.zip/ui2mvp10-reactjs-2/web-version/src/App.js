import React, { Component } from "react";
import { BrowserRouter, Route } from "react-router-dom";

import SideBarManager from "./component/bar/Sidebar-pbam";
import PBAdetail from './component/pages/PBAM/detailPBA'
import Login from "./component/Login/Login";

// import TambahAkun from "./component/Dashboard/TambahAkun";
import Search from "./component/Dashboard/Search";
import TambahCustomer from "./component/TambahAkun/TambahCustomer";
import TambahAsisten from "./component/TambahAkun/TambahAsisten";
import TambahKepalaAsisten from "./component/TambahAkun/TambahKepalaAsisten";

import Customer from "./component/Dashboard/Customer";
import Asisten from "./component/Dashboard/Asisten";
import KepalaAsisten from "./component/Dashboard/KepalaAsisten";

import DetailCustomer from "./component/DetailUser/DetailCustomer";
import DetailAsisten from "./component/DetailUser/DetailAsisten";
import DetailKepalaAsisten from "./component/DetailUser/DetailKepalaAsisten";

import ResetPass from "./component/Reset/ResetPass";
import ResetPBAM from "./component/Reset/ResetPBAM";
import ResetPBA from "./component/Reset/ResetPBA";
import ResetPCU from "./component/Reset/ResetPCu";
class App extends Component {
  render() {
    return (
      <BrowserRouter>
        <Route path="/" exact component={Login} />
        <Route path="/admin-search" component={Search} />
        {/* <Route path="/admin-tambah-akun" component={TambahAkun} /> */}
        <Route path="/tambah-customer" component={TambahCustomer} />
        <Route path="/tambah-asisten" component={TambahAsisten} />
        <Route path="/tambah-pbam" component={TambahKepalaAsisten} />

        <Route path="/admin-pcu" exact component={Customer} />
        <Route path="/admin-pba" exact component={Asisten} />
        <Route path="/admin-pbam" exact component={KepalaAsisten} />

        <Route path="/admin-pcu/:id_customer" component={DetailCustomer} />
        <Route path="/admin-pba/:id_asisten" component={DetailAsisten} />
        <Route
          path="/admin-pbam/:id_kepalaasisten"
          component={DetailKepalaAsisten}
        />

        <Route path="/reset-pass" component={ResetPass} />
        {/* <Route path="/reset-pbam" component={ResetPBAM} />
        <Route path="/reset-pba" component={ResetPBA} />
        <Route path="/reset-pcu" component={ResetPCU} /> */}

        {/* <SideBar /> */}

        <Route path="/sidebarManager" component={SideBarManager} />
       
      </BrowserRouter>
    );
  }
}

export default App;
