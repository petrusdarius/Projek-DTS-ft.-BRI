import React, { Component } from "react";
import { Link } from "react-router-dom";
import "./Dashboard.css";

export default class Dashboard extends Component {
  render() {
    return (
      <div
        className="sidenav list-group rounded-0 list-group-flush"
        style={{ height: "100%" }}
      >
        <Link
          to="/"
          className="list-group-item list-group-item-action disabled text-center bg-dark"
        >
          <i
            className="fas fa-user-circle fa-3x"
            style={{
              textAlign: "center",
              // width: "100%",
              color: "#f6f6f6",
              // marginTop: "20px",
            }}
          ></i>
          <p style={{ color: "white", marginBottom: 0 }}>Admin Brimo</p>
        </Link>
        <Link
          to="/admin-search"
          className="list-group-item list-group-item-action bg-dark text-center"
        >
          <i
            className="fas fa-house-user fa-2x"
            style={{
              // textAlign: "center",
              // width: "100%",
              color: "salmon",
            }}
          ></i>
          <p style={{ color: "white", marginBottom: 0 }}>Home</p>
        </Link>
        <Link
          to="/admin-pcu"
          className="list-group-item list-group-item-action bg-dark text-center"
        >
          <i
            className="fas fa-house-user fa-2x"
            style={{
              // textAlign: "center",
              // width: "100%",
              color: "green",
            }}
          ></i>
          <p style={{ color: "white", marginBottom: 0 }}>PCu List</p>
        </Link>
        <Link
          to="/admin-pba"
          className="list-group-item list-group-item-action bg-dark text-center"
        >
          <i
            className="fas fa-user-friends fa-2x"
            style={{
              // textAlign: "center",
              // width: "100%",
              color: "red",
            }}
          ></i>
          <p style={{ color: "white", marginBottom: 0 }}>PBA List</p>
        </Link>
        <Link
          to="/admin-pbam"
          className="list-group-item list-group-item-action bg-dark text-center"
        >
          <i
            className="fas fa-user-cog fa-2x"
            style={{
              // textAlign: "center",
              // width: "100%",
              color: "blue",
            }}
          ></i>
          <p style={{ color: "white" }}>PBAM List</p>
        </Link>
        <Link
          to="/"
          className="list-group-item list-group-item-action bg-dark text-center"
        >
          <i
            className="fas fa-sign-out-alt fa-2x"
            style={{
              // textAlign: "center",
              // width: "100%",
              color: "whitesmoke",
            }}
          ></i>
          <p style={{ color: "white" }}>Log Out</p>
        </Link>
      </div>
    );
  }
}
