import Axios from "axios";
import React, { Component } from "react";
import Button from "../Button/Button";
import Dashboard from "./Dashboard";

export default class KepalaAsisten extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pbamLists: [],
    };
  }

  componentDidMount() {
    Axios.get("https://5fb8593e2f145f0016c3c527.mockapi.io/PBAM").then(
      (response) => {
        this.setState({
          pbamLists: response.data,
        });
      }
    );
  }
  render() {
    const { pbamLists } = this.state;
    return (
      <>
        <div className="row" style={{ width: "100%" }}>
          <div className="col-md-2">
            <Dashboard />
          </div>

          {/* Konten PCU List */}
          <div className="col-md-10 pr-5 mt-5">
            <h4>Personal Banking Asisstant List Manager</h4>
            <hr />
            <table className="table table-bordered table-hover table-sm mt-5">
              <thead>
                <tr className="table-primary text-center">
                  <th scope="col">No.</th>
                  <th scope="col">Nama</th>
                  <th scope="col">Telepon</th>
                  <th scope="col">Kantor Cabang</th>
                  <th scope="col">Email</th>
                  <th scope="col">Ket</th>
                  <th scope="col">Active</th>
                </tr>
              </thead>
              <tbody>
                {pbamLists.map((pbam, index) => {
                  return (
                    <tr key={index}>
                      <th scope="row">{index + 1}</th>
                      <td>{pbam.name}</td>
                      <td>{pbam.phone}</td>
                      <td>{pbam.cabang}</td>
                      <td>{pbam.email}</td>
                      <td>
                        <a href={"/admin-pbam/" + pbam.id}>See details</a>
                      </td>
                      <td className="d-flex justify-content-around">
                        <Button
                          classes={"btn btn-success btn-sm"}
                          action={"Enable"}
                          to="/"
                        />
                        <Button
                          classes={"btn btn-danger btn-sm"}
                          action={"Disable"}
                          to="/"
                        />
                      </td>
                    </tr>
                  );
                })}
                {/* <tr>
                  <th scope="row">2</th>
                  <td>Nurul</td>
                  <td>(021) 444555</td>
                  <td>
                    Kantor Pusat Gedung BRI 1, Jl. Jenderal Sudirman Kav.44-46,
                    Jakarta
                  </td>
                  <td>basri@gmail.com</td>
                  <td>
                    <a href="/">See details</a>
                  </td>
                  <td className="d-flex justify-content-around">
                   
                    <Button
                      classes={"btn btn-success btn-sm"}
                      action={"Enable"}
                      to="/"
                    />
                    <Button
                      classes={"btn btn-danger btn-sm"}
                      action={"Disable"}
                      to="/"
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">3</th>
                  <td>Fatimah</td>
                  <td>(044) 346598</td>
                  <td>
                    Kantor Cabang BRI Pandanaran, Jl. Pandanaran No.75, Semarang
                  </td>
                  <td>rini@yahoo.com</td>
                  <td>
                    <a href="/">See details</a>
                  </td>
                  <td className="d-flex justify-content-around">
                   
                    <Button
                      classes={"btn btn-success btn-sm"}
                      action={"Enable"}
                      to="/"
                    />
                    <Button
                      classes={"btn btn-danger btn-sm"}
                      action={"Disable"}
                      to="/"
                    />
                  </td>
                </tr> */}
              </tbody>
            </table>
            <a href="/tambah-pbam">
              <i className="fas fa-plus-circle">Add PBAM</i>
            </a>
            <br />
            {/* <a href="/reset-pbam">Reset Password</a> */}
          </div>
        </div>
      </>
    );
  }
}
