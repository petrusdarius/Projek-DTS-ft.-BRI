import React, { Component } from "react";
import { Link } from "react-router-dom";
import "axios";
import Dashboard from "./Dashboard";
import "axios";
import Axios from "axios";
// import Calendar from "react-calendar";
// import "react-calendar/dist/Calendar.css";
// import moment from "moment";

export default class Search extends Component {
  constructor() {
    super();
    this.state = {
      date: [],
    };
  }

  handleSearch = (e) => {
    let searchID = e.target.value;
    console.log(searchID);
  };

  componentDidMount() {
    Axios.get(
      "https://cdn.jsdelivr.net/gh/niyoko/libur-nasional/data/2020.json"
    ).then((result) => this.setState({ date: result.data }));
  }
  render() {
    return (
      <>
        <div className="row justify-content-between" style={{ width: "100%" }}>
          <div className="col-md-2">
            <Dashboard />
          </div>

          {/* Konten PCU List */}
          <div className="col-md-5 mt-5">
            <h4>Temukan User</h4>
            <hr />
            <div className="input-group mb-3 mt-5">
              <input
                id="search"
                type="text"
                className="form-control"
                placeholder="Search User (Name, ID, Role)"
                aria-label="Recipient's username"
                aria-describedby="button-addon2"
                onChange={this.handleSearch}
                autoFocus
              />
              <div className="input-group-append">
                <button
                  className="btn btn-outline-secondary"
                  type="button"
                  id="button-addon2"
                >
                  Search
                </button>
              </div>
            </div>
          </div>
          <div className="col-md-5 mt-5">
            <h4>Atur jadwal libur nasional</h4>
            <hr />
            {/* {this.state.date.map((data, index) => (
              <li key={index}>
                Tanggal {data.date} adalah hari libur {data.description}
              </li>
            ))} */}

            {/* <Calendar /> */}
            <div className="from-group">
              <div className="row">
                <div className="col-3">
                  <label htmlFor="start">Mulai :</label>
                </div>
                <div className="col">
                  <input type="date" name="mulai" id="start" />
                </div>
              </div>
            </div>
            <div className="from-group">
              <div className="row">
                <div className="col-3">
                  <label htmlFor="end">Selesai :</label>
                </div>
                <div className="col">
                  <input type="date" name="mulai" id="end" />
                </div>
              </div>
            </div>
            <div class="row">
              <div className="col-3">
                <div className="form-group">
                  <label htmlFor="ket" className="ket">
                    Keterangan :
                  </label>
                </div>
              </div>
              <div className="col">
                <textarea
                  name="keterangan"
                  id="ket"
                  cols="30"
                  rows="4"
                ></textarea>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
