import React, { Component } from "react";
import { Link } from "react-router-dom";
import "axios";
import Axios from "axios";
import Dashboard from "./Dashboard";
import Button from "../Button/Button";

export default class Customer extends Component {
  constructor() {
    super();
    this.state = {
      pcuLists: [],
    };
  }

  // Data API
  componentDidMount() {
    Axios.get("https://5fb8593e2f145f0016c3c527.mockapi.io/PCu").then(
      (response) => {
        this.setState({
          pcuLists: response.data,
        });
      }
    );
  }

  render() {
    const { pcuLists } = this.state;
    return (
      <>
        <div className="row" style={{ width: "100%" }}>
          <div className="col-md-2">
            <Dashboard />
          </div>

          {/* Konten PCU List */}
          <div className="col-md-10 pr-5 mt-5">
            <h4>Priority Customer List</h4>
            <hr />
            <table className="table table-bordered table-hover table-sm mt-5">
              <thead>
                <tr className="table-primary text-center">
                  <th scope="col">No.</th>
                  <th scope="col">Nama</th>
                  <th scope="col">Telepon</th>
                  {/* <th scope="col">Alamat</th> */}
                  <th scope="col">Email 1</th>
                  <th scope="col">Email 2</th>
                  <th scope="col">Ket</th>
                  <th scope="col">Active</th>
                </tr>
              </thead>
              <tbody>
                {pcuLists.map((pcu, index) => {
                  return (
                    <tr key={index}>
                      <th scope="row">{index + 1}</th>
                      <td>{pcu.name}</td>
                      <td>{pcu.phone}</td>
                      <td>{pcu.email_1}</td>
                      <td>{pcu.email_2}</td>
                      <td>
                        <Link to={"/admin-pcu/" + pcu.id}>See details</Link>
                      </td>
                      <td className="d-flex justify-content-around">
                        <Button
                          classes={"btn btn-success btn-sm"}
                          action={"Enable"}
                          to="/"
                        />
                        <Button
                          classes={"btn btn-danger btn-sm"}
                          action={"Disable"}
                          to="/"
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <Link to="/tambah-customer">
              <i className="fas fa-plus-circle">Add PCu</i>
            </Link>
            <br />
            {/* <a href="/reset-pcu">Reset Password</a> */}
          </div>
        </div>
      </>
    );
  }
}
