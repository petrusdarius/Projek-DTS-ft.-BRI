// SideBar.js

import React, { Component } from "react";
import { Link } from "react-router-dom";
import "axios";
import Dashboard from "./Dashboard";

class TambahAkun extends Component {
  render() {
    return (
      <>
        <div className="row" style={{ width: "100%" }}>
          <div className="col-md-2">
            <Dashboard />
          </div>

          {/* Konten Tambah akun */}
          <div className="col-md-10 pr-5 mt-5">
            <h4>Tambah Akun</h4>
            <hr />
            <form className="mt-5">
              <div className="form-group">
                <label for="nama">Nama Lengkap</label>
                <input
                  type="text"
                  className="form-control"
                  id="nama"
                  required
                  autoFocus
                />
              </div>
              <div className="row">
                <div className="col">
                  <div className="form-group">
                    <label for="email-1">Email address 1</label>
                    <input
                      type="email"
                      className="form-control"
                      id="email-1"
                      required
                    />
                  </div>
                </div>
                <div className="col">
                  <div className="form-group">
                    <label for="email-2">Email address 2</label>
                    <input
                      type="email"
                      className="form-control"
                      id="email-2"
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="form-group">
                <label for="alamat">Alamat</label>
                <input type="text" className="form-control" id="alamat" />
              </div>

              <div className="row">
                <div className="col">
                  <div className="form-group">
                    <label for="nomor-telepon">Nomor Telepon</label>
                    <input
                      type="number"
                      className="form-control"
                      id="nomor-telepon"
                    />
                  </div>
                </div>
                <div className="col">
                  <div className="form-group">
                    <label for="roles">Role</label>
                    <select className="form-control" id="role">
                      <option>Personal Customer</option>
                      <option>Personal Banking Asisstant</option>
                      <option>Personal Banking Asisstant Manager</option>
                    </select>
                  </div>
                </div>
              </div>

              <button type="submit" class="btn btn-primary">
                Submit
              </button>
            </form>
          </div>
        </div>
      </>
    );
  }
}
export default TambahAkun;
