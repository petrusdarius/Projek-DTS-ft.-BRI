import React, { Component } from "react";
import Dashboard from "./Dashboard";
import Button from "../Button/Button";
import "axios";
import Axios from "axios";

export default class Asisten extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pbaLists: [],
    };
  }

  componentDidMount() {
    Axios.get("https://5fb8593e2f145f0016c3c527.mockapi.io/PBA").then(
      (response) => {
        this.setState({
          pbaLists: response.data,
        });
      }
    );
  }
  render() {
    return (
      <>
        <div className="row" style={{ width: "100%" }}>
          <div className="col-md-2">
            <Dashboard />
          </div>

          {/* Konten PCU List */}
          <div className="col-md-10 pr-5 mt-5">
            <h4>Personal Business Asisstant List</h4>
            <hr />
            <table className="table table-bordered table-hover table-sm mt-5">
              <thead>
                <tr className="table-primary text-center">
                  <th scope="col">No.</th>
                  <th scope="col">Nama</th>
                  <th scope="col">Telepon</th>
                  <th scope="col">Kantor Cabang</th>
                  <th scope="col">Email</th>
                  <th scope="col">Ket</th>
                  <th scope="col">Active</th>
                </tr>
              </thead>
              <tbody>
                {this.state.pbaLists.map((pba, index) => {
                  return (
                    <tr key={index}>
                      <th scope="row">{index + 1}</th>
                      <td>{pba.name}</td>
                      <td>{pba.phone}</td>
                      <td>{pba.kacab}</td>
                      <td>{pba.email}</td>
                      <td>
                        <a href={"/admin-pba/" + pba.id}>See details</a>
                      </td>
                      <td className="d-flex justify-content-around">
                        <Button
                          classes={"btn btn-success btn-sm"}
                          action={"Enable"}
                        />
                        <Button
                          classes={"btn btn-danger btn-sm"}
                          action={"Disable"}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <a href="/tambah-asisten">
              <i className="fas fa-plus-circle">Add PBA</i>
            </a>
            <br />
            {/* <a href="/reset-pba">Reset Password</a> */}
          </div>
        </div>
      </>
    );
  }
}
