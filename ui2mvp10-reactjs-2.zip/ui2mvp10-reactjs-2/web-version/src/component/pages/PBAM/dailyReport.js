import React, { Component } from 'react';
import {Link} from 'react-router-dom';

class DailyReport extends Component {
    state = {
        reportpba: [],
        loading: true,
        error: false
    }

    componentDidMount() {
        fetch('https://5fb9bede7f538800165a5701.mockapi.io/Report')
        .then(response => {
            if(response.ok) {
                return response.json()
            } else {
                throw new Error('Ambil data gagal')
            }
        })
        .then(
            data => this.setState({ reportpba: data, loading: false})
            )
        .catch(error => this.state({ error: error, loading: true}))
    }

    render() {
        const {error, loading,reportpba} = this.state
        // API
        if(error) {
            return <p>{error.message}</p>
        }

        if(loading) {
            return <p>loading...</p>
        }

        const reportlist = reportpba.map(laporan => {
            return(
                <div className='col-sm-4' style={{marginTop:'20px'}}>
                        <div key={laporan.id} className='card bg-light text-center'>
                            {/* <Link to={'/sidebarManager/listPBA/detailPBA'}> */}
                                <h2>{laporan.name}</h2>
                            {/* </Link> */}
                            <p>{laporan.email}</p>
                            <a href={`/sidebarManager/daily-report/detailReport/${laporan.id}`} className="btn btn-primary" style={{ float: 'right' }}>Details</a> 
                        </div>
                    </div>
            )
        })
        return (
            <div className='container'>
                {/* hny utk debug */}
                <h1 className='text-center' style={{ fontFamily: 'Roboto Slab' }}>Laporan Harian PBA </h1>

                {/* search bar */}
                {/* <form class="form-inline" style={{margin:'30px'}}>
                    <input class="form-control mx-auto" type="search" placeholder="Search" aria-label="Search" /> */}
                    {/* <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button> */}
                {/* </form> */}
                <div className='row'>
                    {reportlist}                                  
                </div>
            </div>
        )
    }
}

export default DailyReport