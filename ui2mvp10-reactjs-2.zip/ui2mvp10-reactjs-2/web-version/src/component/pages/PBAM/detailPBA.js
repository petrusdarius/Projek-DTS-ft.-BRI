import React, { Component } from 'react';
import { RangeDatePicker } from 'react-google-flight-datepicker';
import 'react-google-flight-datepicker/dist/main.css';
import Axios from 'axios';


class PBAdetail extends Component {

    state = {
        datapcu: [],
        jadwalcuti: [],
        listfeed: [],
        datapba: [],
        loading: true,
        dataCuti: {
            mulai: '',
            akhir: '',
            keterangan: ''
        }
    }

    postCuti = () => {
        Axios.post(
            'https://5fb9bede7f538800165a5701.mockapi.io/Cuti',
            this.state.dataCuti
        ).then((result) => {
            console.log(result);
        })
    }

    handleFormChange = (e) => {
        let newCuti = { ...this.state.dataCuti };
        newCuti[e.target.name] = e.target.value;
        this.setState({
            dataCuti: newCuti,
        });
    };

    // onDateChange = (e)

    handleFormSubmit = () => {
        this.postCuti();
    };
    componentDidMount() {
        const id = this.props.match.params.id_detailpba
        // detailpba
        fetch('https://5fb8593e2f145f0016c3c527.mockapi.io/PBA/' + id)
            .then(response => {
                if (response.ok) {
                    return response.json()
                } else {
                    throw new Error('Ambil data gagal')
                }
            })

            .then(data => this.setState({
                datapba: data, loading: false
            }))
        // feedback
        fetch('https://5fb9bede7f538800165a5701.mockapi.io/feedback')
            .then(res => {
                if (res.ok) {
                    return res.json()
                }
            })
            .then(
                list => this.setState({ listfeed: list, loading: false })
            )

        // cuti
        fetch('https://5fb9bede7f538800165a5701.mockapi.io/Cuti')
            .then(resp => {
                if (resp.ok) {
                    return resp.json()
                }
            })
            .then(
                tglcuti => this.setState({ jadwalcuti: tglcuti, loading: false })
            )

        // PCu list
        fetch('https://5fb8593e2f145f0016c3c527.mockapi.io/PCu')
            .then(respon => {
                if (respon.ok) {
                    return respon.json()
                }
            })
            .then(
                daftarpcu => this.setState({ datapcu: daftarpcu, loading: false })
            )

    }
    render() {
        const { loading, datapba, listfeed, jadwalcuti, datapcu } = this.state
        if (loading) {
            return <p>Loading ...</p>
        }

        // console.log(this.props)
        const haricuti = jadwalcuti.map((cuti, index) => {
            return (
                <tbody>
                    <tr>
                        <th scope="row">{index + 1}</th>
                        <td>{cuti.mulai}</td>
                        <td>{cuti.akhir}</td>
                        <td>{cuti.keterangan}</td>

                    </tr>
                </tbody>
            )
        })


        const feedback = listfeed.map(feed => {
            return (
                <div class="carousel-item" data-interval='4000'>
                    <div class="card shadow-sm p-3 mb-5 bg-white rounded" style={{ margin: '20px' }}>

                        <div class="card-body">
                            <h5 class="card-text">{feed.name}</h5>
                            <p>{feed.date}</p>
                            <p>Lokasi : {feed.lokasi}</p>
                            <p>Score: {feed.nilai}</p>
                            <p class="card-text">
                                <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                                <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                                <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                                <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                                <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                            </p>

                            <p>{feed.keterangan}</p>

                        </div>
                    </div>
                </div>
            )
        })

        const pculist = datapcu.map((pcu, index) => {
            return (
                <tbody>
                    <tr>
                        <th scope="row">{index+1}</th>
                        <td>{pcu.name}</td>
                        <td>{pcu.email}</td>
                        <td>{pcu.phone}</td>
                        <td><span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star checked" style={{ color: 'orange' }}></span></td>
                    </tr>
                </tbody>
            )
        })
        return (
            <div className='container'>
                <div class="card" style={{ margin: '20px' }}>
                    <h5 class="card-header text-center">{datapba.name}</h5>  {/*Nama berdasarkan ID PCu */}
                    <div class="card-body">
                        <table style={{ lineHeight: '3' }}>
                            <tr>
                                <td>Email</td>
                                <td>: {datapba.email}</td>
                            </tr>

                            <tr>
                                <td>Kantor Cabang</td>
                                <td>: {datapba.kacab}</td>
                            </tr>

                            <tr>
                                <td>Alamat</td>
                                <td>: {datapba.alamat}</td>
                            </tr>

                            <tr>
                                <td>Telp.</td>
                                <td>: {datapba.phone}</td>
                            </tr>
                        </table>
                    </div>
                </div>

                {/* List PCu*/}
                <div className='listPCu-PBA'>
                    <h5>Daftar PCu yang ditangani</h5>

                    {/* searchbar */}
                    <form class="form-inline" style={{ margin: '30px' }}>
                        <input class="form-control ml-auto" type="search" placeholder="Search" aria-label="Search" />
                        {/* <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button> */}
                    </form>
                    {/* daftar PCu yg ditangani */}
                    <table class="table table-striped" border='1'>
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">PCu</th>
                                <th scope="col">Nama</th>
                                <th scope="col">E-mail</th>
                                <th scope='col'>Telp</th>
                                <th scope="col">Rating</th>
                            </tr>
                        </thead>
                        {pculist}
                    </table>
                    {/* Jadwal libur */}
                    <h2>Jadwal Cuti</h2>
                    <table class="table table-striped" border='1'>
                        <thead class="thead-dark">
                            <tr>
                                <th scope='col'>No</th>
                                <th scope="col">Mulai Cuti</th>
                                <th scope="col">Akhir Cuti</th>
                                <th scope="col">Keterangan</th>


                            </tr>
                        </thead>
                        {haricuti}
                    </table>

                    {/* add cuti */}
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style={{ float: 'right' }}>
                        + tambah cuti
                    </button>

                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Masukkan tanggal Cuti</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <div className='form-group'>

                                        <label for="start">Mulai Cuti:</label>

                                        <input type="date" id="start" name="mulai"
                                            value={this.handleFormChange.value}
                                            min="2020-01-01" max="2021-12-31" onChange={this.handleFormChange} />
                                    </div>

                                    <div className='form-group'>
                                        <label for="end">Akhir Cuti:</label>

                                        <input type="date" id="end" name="akhir"
                                            value={this.handleFormChange.value}
                                            min="2020-01-01" max="2021-12-31" onChange={this.handleFormChange} />
                                    </div>
                                    {/* <RangeDatePicker
                                        startDate={new Date()}
                                        endDate={new Date()} 
                                        startDatePlaceholder="From"
                                        endDatePlaceholder="To"
                                        // onChange={(startDate, endDate) => onDateChange(startDate, endDate)}
                                    /> */}
                                    <div class="form-group">
                                        <label for="exampleFormControlTextarea1">Keterangan Cuti</label>
                                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" onChange={this.handleFormChange} name='keterangan'></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary" onClick={this.handleFormSubmit}>Save changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br />
                    {/* History feedback */}
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li style={{ backgroundColor: 'grey' }} data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li style={{ backgroundColor: 'grey' }} data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                            <li style={{ backgroundColor: 'grey' }} data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                            <li style={{ backgroundColor: 'grey' }} data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                            <li style={{ backgroundColor: 'grey' }} data-target="#carouselExampleIndicators" data-slide-to="4"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active" data-interval='4000'>
                                <div class="card shadow-sm p-3 mb-5 bg-white rounded" style={{ margin: '20px' }}>

                                    <div class="card-body">
                                        <h5 class="card-text">Markonah</h5>
                                        <p>24/ 11 / 20 (08.00 - 09.00)</p>
                                        <p>Lokasi : Kantor Pusat Kota Bunga Api</p>
                                        <p class="card-text">
                                            <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                                            <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                                            <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                                            <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                                            <span class="fa fa-star checked" style={{ color: 'orange' }}></span>
                                        </p>

                                        <p>Lorem ipsum blablablablablablablabla</p>

                                    </div>
                                </div>
                            </div>
                            {feedback}
                        </div>
                    </div>

                </div>
            </div>
        )
    }
}

export default PBAdetail;