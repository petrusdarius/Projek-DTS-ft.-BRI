import React, { Component } from 'react';

class PBARating extends Component {
    state = {
        pbarating: [],
        loading: true,
        error: false
    }

    componentDidMount() {
        fetch('https://5fb9bede7f538800165a5701.mockapi.io/rating')
            .then(response => {
                if (response.ok) {
                    return response.json()
                } else {
                    throw new Error('Ambil data gagal')
                }
            })

            .then((data) => {
                data.sort((a,b) =>b.pertemuan - a.pertemuan || b.rating-a.rating);
                this.setState({pbarating:data})
            }
                // data => this.setState({ pbarating: data, loading: false })
            )
            .catch(error => this.state({ error: error, loading: true }))
    }
    render() {
        console.log(this.props)
        const { error, pbarating } = this.state
        if (error) {
            return <p>{error.message}</p>
        }

        const ratpba = pbarating.map(rating => {
            return (
                <div style={{ marginTop: '30px' }}>
                    <div class="card mb-3 bg-light">
                        <div class="row no-gutters">
                            <div class="col-md-2 text-center">
                                <i class="fas fa-user-circle fa-7x" style={{ textAlign: 'center' }}></i>
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title">{rating.name}</h5>
                                    <p class="card-text">This Week Meeting : {rating.pertemuan}</p>
                                    <p>Score: {rating.rating}</p>
                                    <p class="card-text">
                                        <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                                        <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                                        <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                                        <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                                        <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )
        })
        return (

            <div className='container'>
                <h1 className='text-center' style={{ fontFamily: 'Roboto Slab' }}>PBA Ratings</h1>

                {/* Banner Top PBA */}
                <div class="card">
                    <div class="card-header text-center">

                        <h4>
                            <img
                                src='https://cdn.icon-icons.com/icons2/2474/PNG/512/award_trophy_first_champion_icon_149690.png'
                                width='50px'
                            />
                        MOST VALUABLE PBA
                        <img
                                src='https://cdn.icon-icons.com/icons2/2474/PNG/512/award_trophy_first_champion_icon_149690.png'
                                width='50px'
                            />
                        </h4>

                    </div>
                    <div class="card-body text-center">
                        <h1 class="card-title">Revi A.</h1>
                        {/* dengan banyaknya pertemuan */}
                        <h4>This week meeting : </h4>
                        <h4>10</h4> {/*banyak pertemuan */}
                        <p class="card-text">
                            <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span></p>
                        {/* <a href="#" class="btn btn-primary">Go somewhere</a> */}
                    </div>
                </div>
                {/* end banner top PBA */}

                {/* urutan 2 dan kebawah */}
                {ratpba}

            </div>
        )
    }
}

export default PBARating;