import React, { Component } from 'react';
import {Link} from 'react-router-dom';
import SearchBox from '../../bar/SearchBox'
class ListPBA extends Component {

    state = {
        datapba: [],
        loading: true,
        error: false,
        searchField:'',
    }

    componentDidMount() {
        fetch('https://5fb8593e2f145f0016c3c527.mockapi.io/PBA')
            .then(response => {
                if (response.ok) {
                    return response.json()
                } else {
                    throw new Error('Ambil data gagal')
                }
            })
            .then(
                data => this.setState({ datapba: data, loading: false })
            )
            .catch(error => this.state({ error: error, loading: true }))
    }
    handleChange = (e) => {
        this.setState({searchField:e.target.value})
    }
    render() {
        const { error, loading, datapba,searchField } = this.state
        const filteredPBA = datapba.filter(pba => (
            pba.name.toLowerCase().includes(searchField.toLowerCase())
        ))
        if (error) {
            return <p>{error.message}</p>
        }

        if (loading) {
            return <p>loading...</p>
        }

        const listpba = datapba.map((pba,index) => {
            return (
                    // <div className='col-sm-4' style={{marginTop:'20px'}}>
                    //     <div key={pba.id} className='card bg-light text-center'>
                    //         <Link to={'/sidebarManager/listPBA/detailPBA'}>
                    //             <h2>{pba.name}</h2>
                    //         </Link>
                    //         <p>{pba.email}</p>
                    //     </div>
                    // </div>
                <tbody>
                    <tr>
                        <th scope="row">{index+1}</th>
                        <td>{pba.name}</td>
                        <td>{pba.phone}</td>
                        <td>{pba.kacab}
                  </td>
                        <td>{pba.email}</td>
                        <td>
                            <a href={"/sidebarManager/listPBA/detailPBA/" +pba.id}>See details</a>
                        </td>
                    </tr>
                </tbody>
            )
        })
        return (
            <div className='container text-center'>
                {/* hny utk debug */}
                <h1 className='text-center' style={{ fontFamily: 'Roboto Slab' }}>Personal Banking Assistant </h1>

                {/* search bar */}
                <SearchBox placeholder='Nama PBA' handleChange={this.handleChange} />

                {/* // <form class="form-inline" style={{ margin: '30px' }}>
                    <input class="form-control mx-auto" type="search" placeholder="Search" aria-label="Search" /> */}
                    {/* <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button> */}
                 {/* </form> */}
                {/* <div className='row'>{listpba}</div> */}
                
                <table className="table table-bordered table-hover table-sm mt-5">
                    <thead>
                        <tr className="table-primary text-center">
                            <th scope="col">No.</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Telepon</th>
                            <th scope="col">Kantor Cabang</th>
                            <th scope="col">Email</th>
                            <th scope="col">Ket</th>
                        </tr>
                    </thead>
                    {listpba}
                </table>


            </div>
        )
    }
}

export default ListPBA