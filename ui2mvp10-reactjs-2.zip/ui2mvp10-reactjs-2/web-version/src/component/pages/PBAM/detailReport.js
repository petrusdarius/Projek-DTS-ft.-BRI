import React, { Component } from 'react';
import SearchBox from '../../bar/SearchBox'

class DetailReport extends Component {
    state ={
        laporan:[],
        loading: true,
    }

    componentDidMount() {
        const id = this.props.match.params.id_report

        fetch('https://5fb9bede7f538800165a5701.mockapi.io/Report/'+ id)
        .then(response => {
            if(response.ok){
                return response.json()
            } else{
                throw new Error ('Ambil data gagal')
            }
        })
        .then(data=>this.setState({
            laporan:data, loading:false
        }))

    }
    render() {
        console.log(this.props)
        const {loading,laporan}=this.state
        
        if(loading){
            return<p>Loading...</p>
        }
        
        return (
            <div className='container'>
                {/* judul nama PBA nya */}
                <h1 className='text-center' style={{ fontFamily: 'Roboto Slab' }}>{laporan.name}</h1> {/*Nama berdasarkan ID data */}
                <hr />

                {/* <SearchBox placeholder='masukkan nama' handleChange={(e) => this.setState({searchField:e.target.value})}/> */}
                <form class="form-inline" style={{margin:'30px'}}>
                    <input class="form-control mx-auto" type="search" placeholder="Search" aria-label="Search" />
                    {/* <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>*/}
                </form>
                <div class="card report"  style={{margin:'20px'}}>
                    <h5 class="card-header text-center">{laporan.name}</h5>  {/*Nama berdasarkan ID PCu */}
                    <div class="card-body">

                        <p class="card-text">Waktu Pertemuan : {laporan.waktu_pertemuan}</p>
                        <p class="card-text">Lokasi: {laporan.lokasi}</p>
                        <p class="card-text">Inti Pertemuan : {laporan.inti}</p>
                        <p class="card-text">Rating PCu: </p>
                        <p class="card-text text-center">
                            <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                            <span class="fa fa-star fa-2x checked" style={{ color: 'orange' }}></span>
                        </p>

                    </div>
                </div>
            </div>
        )
    }
}

export default DetailReport