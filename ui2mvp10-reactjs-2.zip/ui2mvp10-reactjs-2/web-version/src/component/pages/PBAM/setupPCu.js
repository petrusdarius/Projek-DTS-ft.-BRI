import React, { Component } from 'react';

class SetupPCu extends Component {

    state = {
        setPCu: [],
        listpba: [],
        loading: true,
        error: false
    }

    componentDidMount() {
        fetch('https://5fb8593e2f145f0016c3c527.mockapi.io/PCu')
            .then(response => {
                if (response.ok) {
                    return response.json()
                } else {
                    throw new Error('Ambil data gagal')
                }
            })
            .then(
                data => this.setState({ setPCu: data, loading: false })
            )
            .catch(error => this.state({ error: error, loading: true }))

        fetch('https://5fb8593e2f145f0016c3c527.mockapi.io/PBA')
            .then(res => {
                if (res.ok) {
                    return res.json()
                }
            })
            .then(
                list => this.setState({ listpba: list, loading: false })
            )
            .catch(error => this.state({ error: error, loading: true }))
    }
    render() {

        const { error, loading, setPCu, listpba } = this.state

        if (error) {
            return <p>{error.message}</p>
        }

        if (loading) {
            return <p>Loading...</p>
        }

        const selectpba = listpba.map(pba => {
            return (
                <option value="1">{pba.name}</option>

            )
        })

        const listpcu = setPCu.map((pcu, index) => {
            return (
                <tbody>
                    <tr>
                        <th scope="row">{index + 1}</th>
                        <td>{pcu.name}</td>
                        <td>{pcu.email_1}
                        </td>
                        <td>{pcu.email_2}</td>
                        <td>{pcu.phone}</td>
                        <select class="custom-select" id="inputGroupSelect01">
                            <option selected>Choose...</option>
                            {selectpba}
                        </select>
                        <td>
                            <button type="button" class="btn btn-primary">Submit</button>
                        </td>
                    </tr>
                </tbody>
            )
        })
        return (
            <div className='container bg-light'>
                <h1>Setup Customer Prioritas</h1>
                <hr />

                {/* table set pcunya */}
                <h4>Daftar PBA dan PCu</h4>
                <table class="table table-striped" border='1'>
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">PCu</th>
                            <th scope="col">Nama</th>
                            <th scope="col">E-mail</th>
                            <th scope="col">E-mail2</th>
                            <th scope='col'>Telp</th>
                            <th scope="col">PBA</th>
                            <th scope='col'>Submit</th>
                        </tr>
                    </thead>
                    {listpcu}
                    {/* <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>Tuti</td>
                            <td>tutiastuti@mail.com</td>
                            <td>(0220)235-180</td>
                            <td><select class="custom-select" id="inputGroupSelect01">
                                <option selected>Choose...</option>
                                <option value="1">Revi</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                            </td>

                            <td className='text-center'>
                                <button type="button" class="btn btn-primary">Submit</button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Tuti</td>
                            <td>tutiastuti@mail.com</td>
                            <td>(0220)235-180</td>
                            <td><select class="custom-select" id="inputGroupSelect01">
                                <option selected>Choose...</option>
                                <option value="1">Revi</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                            </td>

                            <td className='text-center'>
                                <button type="button" class="btn btn-primary">Submit</button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td>Tuti</td>
                            <td>tutiastuti@mail.com</td>
                            <td>(0220)235-180</td>
                            <td><select class="custom-select" id="inputGroupSelect01">
                                <option selected>Choose...</option>
                                <option value="1">Revi</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                            </td>

                            <td className='text-center'>
                                <button type="button" class="btn btn-primary">Submit</button>
                            </td>
                        </tr>
                    </tbody> */}
                </table>
            </div>
        )
    }
}

export default SetupPCu;