import React, { Component } from "react";
import { Link } from "react-router-dom";
import Axios from "axios";

export default class TambahCustomer extends Component {
  constructor() {
    super();
    this.state = {
      dataAsisten: {
        id: "",
        name: "",
        email: "",
        kacab: "",
        alamat: "",
        phone: "",
      },
      notif: false,
    };
  }

  postToApi = () => {
    Axios.post(
      "https://5fb8593e2f145f0016c3c527.mockapi.io/PBA",
      this.state.dataAsisten
    ).then((result) => {
      console.log(result);
    });
  };

  handleFormChange = (e) => {
    let NewDataAsisten = { ...this.state.dataAsisten };
    NewDataAsisten[e.target.name] = e.target.value;
    this.setState({
      dataAsisten: NewDataAsisten,
    });
  };

  handleFormSubmit = () => {
    this.postToApi();
    this.setState({ notif: true });
  };
  render() {
    return (
      <>
        <nav aria-label="breadcrumb">
          <div className="container">
            <ol className="breadcrumb bg-white mb-0">
              <li className="breadcrumb-item">
                <Link to="/admin-pba">PBA List</Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                Tambah PBA
              </li>
            </ol>
          </div>
        </nav>

        <div className="container">
          <div className="row mx-auto" style={{ width: 700 }}>
            <div className="col">
              <h4>Tambah Akun Personal Business Asisstant</h4>
              <hr />
              {/* <form
                className="mt-2 p-4"
                style={{
                  border: "1px solid grey",
                  borderRadius: 5,
                  boxShadow: "0 0 5px 2px #797d79",
                }}
              > */}
              <div
                className="mt-2 p-4"
                style={{
                  border: "1px solid grey",
                  borderRadius: 5,
                  boxShadow: "0 0 5px 2px #797d79",
                }}
              >
                {this.state.notif ? (
                  <div class="alert alert-primary" role="alert">
                    Selamat, anda sudah menjadi Asisten
                  </div>
                ) : (
                  ""
                )}
                <div className="row">
                  <div className="col">
                    <div className="form-group">
                      <label htmlFor="nama">Nama Lengkap</label>
                      <input
                        type="text"
                        className="form-control"
                        id="nama"
                        name="name"
                        onChange={this.handleFormChange}
                        required
                        autoFocus
                      />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col">
                    <div className="form-group">
                      <label htmlFor="email">Email</label>
                      <input
                        type="email"
                        className="form-control"
                        id="email"
                        name="email"
                        onChange={this.handleFormChange}
                        required
                      />
                    </div>
                  </div>
                  <div className="col">
                    <div className="form-group">
                      <label htmlFor="password">Password</label>
                      <input
                        type="password"
                        className="form-control"
                        id="password"
                        name="password"
                        onChange={this.handleFormChange}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col">
                    <div className="form-group">
                      <label htmlFor="cabang">Kantor Cabang</label>
                      <select
                        className="form-control"
                        id="cabang"
                        name="kacab"
                        onChange={this.handleFormChange}
                      >
                        <option selected>Pilih Kantor Cabang</option>
                        <option>Bunga Api</option>
                        <option>Bunga Air</option>
                        <option>Bunga Indah</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col">
                    <div className="form-group">
                      <label htmlFor="nomor-telepon">Nomor Telepon</label>
                      <input
                        type="tel"
                        className="form-control"
                        id="nomor-telepone"
                        pattern="[0-9]{12}"
                        name="phone"
                        onChange={this.handleFormChange}
                        required
                      />
                      <small>Format 12 digit: 08xxxxxxxxxx</small>
                    </div>
                  </div>
                  <div className="col">
                    <div className="form-group">
                      <label htmlFor="role" className="col-sm-2 col-form-label">
                        Role
                      </label>
                      <div className="col-sm-10">
                        <input
                          type="text"
                          readOnly
                          className="form-control-plaintext"
                          id="role"
                          value="Personal Business Asisstant"
                          style={{ width: 295 }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="btn btn-primary"
                  onClick={this.handleFormSubmit}
                >
                  Submit
                </button>
                {/* </form> */}
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
