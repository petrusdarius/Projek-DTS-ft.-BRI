import React, { Component } from "react";
import { Link } from "react-router-dom";
import Axios from "axios";

export default class TambahCustomer extends Component {
  constructor() {
    super();
    this.state = {
      dataCustomer: {
        id: "",
        name: "",
        password: "",
        email_1: "",
        email_2: "",
        phone: "",
      },
      notif: false,
    };
  }

  postToApi = () => {
    Axios.post(
      "https://5fb8593e2f145f0016c3c527.mockapi.io/PCu/",
      this.state.dataCustomer
    ).then((result) => {
      console.log(result);
    });
  };

  handleFormChange = (e) => {
    // membuat cloningan untuk menyimpan mentarget attr name agar lebih mudah seStatenya
    let newDataCustomer = { ...this.state.dataCustomer };
    // untuk sementara, ID pake waktu sekarang. tapi bermaslaah pada pembacaan di mockapinya
    let timestamp = new Date().getTime();
    newDataCustomer["id"] = timestamp.toString();
    newDataCustomer[e.target.name] = e.target.value;
    this.setState({
      dataCustomer: newDataCustomer,
    });
  };

  handleFormSubmit = () => {
    // console.log(this.state.dataCustomer);
    this.postToApi();
    this.setState({ notif: true });
  };
  render() {
    return (
      <>
        <nav aria-label="breadcrumb">
          <div className="container">
            <ol className="breadcrumb bg-white mb-0">
              <li className="breadcrumb-item">
                <Link to="/admin-pcu">PCu List</Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                Tambah PCu
              </li>
            </ol>
          </div>
        </nav>

        <div className="container">
          <div className="row mx-auto" style={{ width: 700 }}>
            <div className="col">
              <h4>Tambah Akun Priority Customer</h4>
              <hr />
              {/* <form
                className="mt-2 p-4"
                style={{
                  border: "1px solid grey",
                  borderRadius: 5,
                  boxShadow: "0 0 5px 2px #797d79",
                }}
                onSubmit={this.TambahCustomer}
              > */}
              <div
                className="mt-2 p-4"
                style={{
                  border: "1px solid grey",
                  borderRadius: 5,
                  boxShadow: "0 0 5px 2px #797d79",
                }}
              >
                {this.state.notif ? (
                  <div class="alert alert-primary" role="alert">
                    Selamat, anda sudah menjadi Customer Kami
                  </div>
                ) : (
                  ""
                )}
                <div className="row">
                  <div className="col">
                    <div className="form-group">
                      <label htmlFor="nama">Nama Lengkap</label>
                      <input
                        type="text"
                        className="form-control"
                        id="nama"
                        name="name"
                        onChange={this.handleFormChange}
                        required
                        autoFocus
                      />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col">
                    <div className="form-group">
                      <label htmlFor="email-1">Email address 1</label>
                      <input
                        type="email"
                        className="form-control"
                        id="email-1"
                        name="email_1"
                        onChange={this.handleFormChange}
                        required
                      />
                    </div>
                  </div>
                  <div className="col">
                    <div className="form-group">
                      <label htmlFor="email-2">Email address 2</label>
                      <input
                        type="email"
                        className="form-control"
                        id="email-2"
                        name="email_2"
                        onChange={this.handleFormChange}
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* <div className="form-group">
                  <label for="alamat">Alamat</label>
                  <input type="text" className="form-control" id="alamat" />
                </div> */}

                <div className="row">
                  <div className="col">
                    <div className="form-group">
                      <label htmlFor="nomor-telepon">Nomor Telepon</label>
                      <input
                        type="tel"
                        className="form-control"
                        id="nomor-telepone"
                        pattern="[0-9]{12}"
                        name="phone"
                        onChange={this.handleFormChange}
                        required
                      />
                      <small>Format 12 digit: 08xxxxxxxxxx</small>
                    </div>
                  </div>
                  <div className="col">
                    <div className="form-group">
                      <label htmlFor="password">Password</label>
                      <input
                        type="password"
                        className="form-control"
                        id="password"
                        name="password"
                        onChange={this.handleFormChange}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col">
                    <div className="form-group row">
                      <label htmlFor="role" className="col-sm-2 col-form-label">
                        Role :
                      </label>
                      <div className="col-sm-10">
                        <input
                          type="text"
                          readOnly
                          className="form-control-plaintext"
                          id="role"
                          value="Priority Customer"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="btn btn-primary"
                  onClick={this.handleFormSubmit}
                >
                  Submit
                </button>
                {/* </form> */}
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
