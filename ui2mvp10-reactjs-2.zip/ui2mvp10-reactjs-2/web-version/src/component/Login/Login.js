import Axios from "axios";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import Logo from "../../assets/img/logo.png";

export default class Login extends React.Component {
  constructor() {
    super();
    this.state = {
      err: "",
    };
  }
  login = (e) => {
    e.preventDefault();
    let email = e.target.elements.email.value;
    let password = e.target.elements.password.value;

    if (email === "emailManager@mail.com" && password === "passManager") {
      alert("Login berhasil. Anda adalah seorang Manager");
      this.props.history.push("/sidebarManager");
    } else if (email === "emailAdmin@mail.com" && password === "passAdmin") {
      alert("Login berhasil. Anda adalah seorang Admin");
      this.props.history.push("/admin-search");
    } else {
      this.setState({
        err: alert(
          "Login gagal. Email & password tidak sinkron atau anda belum bergabung dengan kami"
        ),
      });
    }
  };

  render() {
    return (
      <>
        <div
          className="container d-flex justify-content-center"
          style={{ marginTop: 40, marginBottom: 40 }}
        >
          <form
            className="px-5 text-center py-3"
            onSubmit={this.login}
            style={{
              border: "1px solid grey",
              borderRadius: 5,
              boxShadow: "0 0 5px 2px #797d79",
            }}
          >
            {this.state.err !== "" ? this.state.err : ""}
            <img
              src={Logo}
              alt="BRI"
              width={250}
              className="mb-2 mx-auto img-fluid"
            />
            <h1 className="mb-3">Sign In</h1>
            <input
              type="email"
              id="email"
              className="form-control mb-3 w-100"
              placeholder="Email Address"
              required
              autoFocus
            />
            <input
              type="password"
              id="password"
              className="form-control"
              placeholder="Password"
              required
            />
            <button
              className="btn btn-lg btn-primary btn-block mt-4"
              type="submit"
            >
              Sign In
            </button>

            <div style={{ marginTop: "15px" }}>
              <Link to="/reset-pass">
                <button
                  type="button"
                  className="btn btn-link"
                  data-toggle="modal"
                  data-target="#exampleModal"
                  style={{ float: "right" }}
                >
                  Lupa Password?
                </button>
              </Link>
            </div>
          </form>
        </div>
      </>
    );
  }
}

// export default function Login() {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");

//   const handleChangeEmail = (e) => {
//     // console.log(e.target.value);
//     const value = e.target.value;
//     setEmail(value);
//   };

//   const handleChangePsssword = (e) => {
//     const value = e.target.value;
//     setPassword(value);
//   };

//   const handleSubmit = () => {
//     const data = {
//       email: email,
//       password: password,
//     };
//     console.log(data);
//   };
//   return (
//     <>
//       <div
//         className="container d-flex justify-content-center"
//         style={{ marginTop: 40, marginBottom: 40 }}
//       >
//         <form
//           className="px-5 text-center py-3"
//           style={{
//             border: "1px solid grey",
//             borderRadius: 5,
//             boxShadow: "0 0 5px 2px #797d79",
//           }}
//         >
//           <img
//             src={Logo}
//             alt="BRI"
//             width={250}
//             className="mb-2 mx-auto img-fluid"
//           />
//           <h1 className="mb-3">Sign In</h1>
//           <input
//             type="email"
//             id="email"
//             className="form-control mb-3 w-100"
//             placeholder="Email Address"
//             value={email}
//             onChange={handleChangeEmail}
//             required
//             autoFocus
//           />
//           <input
//             type="password"
//             id="password"
//             className="form-control"
//             placeholder="Password"
//             value={password}
//             onChange={handleChangePsssword}
//             required
//           />
//           <button
//             className="btn btn-lg btn-primary btn-block mt-4"
//             onClick={handleSubmit}
//           >
//             Sign In
//           </button>

//           <div style={{ marginTop: "15px" }}>
//             <Link to="/reset-pass">
//               <button
//                 type="button"
//                 className="btn btn-link"
//                 data-toggle="modal"
//                 data-target="#exampleModal"
//                 style={{ float: "right" }}
//               >
//                 Lupa Password?
//               </button>
//             </Link>
//           </div>
//         </form>
//       </div>
//     </>
//   );
// }
