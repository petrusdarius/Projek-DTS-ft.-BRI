import React, { Component } from "react";
import { Link } from "react-router-dom";

class ResetPass extends Component {
  render() {
    return (
      <>
        <div className="container">
          <div class="card shadow-sm p-3 mb-5 bg-white rounded" style={{ marginTop: '50px' }}>
            <h5 class="card-header text-center" style={{backgroundColor:'#c6e2ff '}}>Reset Password</h5>
            <div class="card-body">
              <form>
                <div class="form-group">
                  <label for="exampleInputEmail1">Masukkan Alamat Email</label>
                  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" /> 
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Password Baru</label>
                  <input type="password" class="form-control password-baru" id="exampleInputPassword1" />
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Konfirmasi Password Baru</label>
                  <input type="password" class="form-control password-konfirm" id="exampleInputPassword1" />
                </div>
                
                <button type="submit" class="btn btn-primary konfirm-passbaru">Submit</button>
              </form>
            </div>
          </div>
        </div>
      </>
    )
  }
}

export default ResetPass