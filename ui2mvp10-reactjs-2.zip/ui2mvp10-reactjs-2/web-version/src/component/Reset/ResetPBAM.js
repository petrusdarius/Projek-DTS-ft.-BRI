import React, { Component } from 'react'
import {Link} from 'react-router-dom'

class ResetPBAM extends Component {
    render() {
        return (
            <>
                <nav aria-label="breadcrumb">
                    <div className="container">
                        <ol class="breadcrumb bg-white mb-0">
                            <li class="breadcrumb-item">
                                <Link to="/admin-pbam">PBAM List</Link>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Reset PBAM
              </li>
                        </ol>
                    </div>
                </nav>

                <div className="container">
                    <div className="row mx-auto" style={{ width: 700 }}>
                        <div className="col">
                            <h4>Reset Password Personal Banking Assistant Manager</h4>
                            <hr />
                            <form
                                className="mt-2 p-4"
                                style={{
                                    border: "1px solid grey",
                                    borderRadius: 5,
                                    boxShadow: "0 0 5px 2px #797d79",
                                }}
                            >
                                <div className="row">
                                    <div className="col">
                                        <div className="form-group">
                                            <label for="email-1">Email</label>
                                            <input
                                                type="email"
                                                className="form-control"
                                                id="email-reset-pbam"
                                                required
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col">
                                        <div className="form-group">
                                            <label for="password">Password Baru</label>
                                            <input
                                                type="password"
                                                className="form-control"
                                                id="password password-reset-pbam"
                                                required
                                            />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="form-group">
                                            <label for="co-password">Confirm Password Baru</label>
                                            <input
                                                type="password"
                                                className="form-control"
                                                id="co-password co-password-pbam"
                                                required
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div style={{marginBottom:'20px'}}>
                  <label>Kantor Cabang</label>
                <select class="custom-select" id="inputGroupSelect01">
                                <option selected>Pilih Kantor Cabang</option>
                                <option value="1">Bunga Api</option>
                                <option value="2">Bunga Air</option>
                                <option value="3">Bunga Indah</option>
                            </select>
                </div>

                                <div className="row">
                                    <div className="col">
                                        <div className="form-group">
                                            <label for="nomor-id-pbam">ID PBAM</label>
                                            <input
                                                type="number"
                                                className="form-control"
                                                id="nomor-id-pbam"
                                            />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div class="form-group">
                                            <label for="role" class="col-sm-2 col-form-label">
                                                Role
                      </label>
                                            <div class="col-sm-10">
                                                <input
                                                    type="text"
                                                    readonly
                                                    class="form-control-plaintext"
                                                    id="role"
                                                    value="Personal Banking Asisstant Manager"
                                                    style={{ width: 295 }}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary">
                                    Submit
                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}

export default ResetPBAM