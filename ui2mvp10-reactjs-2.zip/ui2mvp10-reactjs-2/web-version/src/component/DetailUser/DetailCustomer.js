import React, { Component } from "react";
import { Link } from "react-router-dom";
import Button from "../Button/Button";
import Axios from "axios";

export default class DetailCustomer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      detailPcu: [],
    };
  }

  componentDidMount() {
    const id = this.props.match.params.id_customer;
    Axios.get("https://5fb8593e2f145f0016c3c527.mockapi.io/PCu/" + id).then(
      (response) => {
        this.setState({
          detailPcu: response.data,
        });
      }
    );
  }
  render() {
    const { detailPcu } = this.state;
    return (
      <>
        <nav aria-label="breadcrumb">
          <div className="container">
            <ol className="breadcrumb bg-white mb-0">
              <li className="breadcrumb-item">
                <Link to="/admin-pcu">PCU List</Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                {detailPcu.name}
              </li>
            </ol>
          </div>
        </nav>

        <div className="jumbotron py-5">
          <div className="container">
            <h1 className="display-4 text-center">{detailPcu.name}</h1>
            <hr className="my-4" />
            <div className="mx-auto" style={{ width: 700 }}>
              <p className="lead text-center font-weight-bold">Biodata</p>
              <table
                style={{
                  width: "400px",
                  margin: "auto",
                  lineHeight: 3,
                }}
              >
                <tbody>
                  <tr>
                    <td>Role</td>
                    <td>: Priority Customer</td>
                  </tr>
                  <tr>
                    <td>Email 1</td>
                    <td>: {detailPcu.email_1}</td>
                  </tr>
                  <tr>
                    <td>Email 2</td>
                    <td>: {detailPcu.email_2}</td>
                  </tr>
                  <tr>
                    <td>Nomor Telpon</td>
                    <td>: {detailPcu.phone}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="text-center mt-2">
              <Button
                classes={"btn btn-success btn-lg m-2"}
                action={"Enable"}
              />
              <Button
                classes={"btn btn-danger btn-lg m-2"}
                action={"Disable"}
              />
              {/* <!-- Button Change Password --> */}
              <button
                type="button"
                className="btn btn-primary btn-lg m-2"
                data-toggle="modal"
                data-target="#modalEdit"
              >
                <i className="fas fa-cogs"></i>
              </button>

              {/* <!-- Modal Change Password --> */}
              <div
                className="modal fade"
                id="modalEdit"
                tabIndex="-1"
                aria-labelledby="exampleModalLabel"
                aria-hidden="true"
              >
                <div className="modal-dialog modal-dialog-centered">
                  <div className="modal-content">
                    <div className="modal-header">
                      <h5 className="modal-title" id="exampleModalLabel">
                        Change Password
                      </h5>
                      <button
                        type="button"
                        className="close"
                        data-dismiss="modal"
                        aria-label="Close"
                      >
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div className="modal-body">
                      <form action="">
                        <div className="row">
                          <div className="col">
                            <div className="form-group text-left">
                              <label htmlFor="password-baru">
                                Password Baru
                              </label>
                              <input
                                type="password"
                                className="form-control"
                                id="password-baru"
                                required
                              />
                            </div>
                          </div>

                          <div className="col">
                            <div className="form-group text-left">
                              <label htmlFor="co-password">
                                Confirm Password
                              </label>
                              <input
                                type="password"
                                className="form-control"
                                id="co-password"
                                required
                              />
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                    <div className="modal-footer">
                      <button
                        type="button"
                        className="btn btn-secondary"
                        data-dismiss="modal"
                      >
                        Close
                      </button>
                      <button type="button" className="btn btn-primary">
                        Save changes
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              {/* <!-- Button Edit Account--> */}
              <button
                type="button"
                className="btn btn-primary btn-lg m-2"
                data-toggle="modal"
                data-target="#modalUpdate"
              >
                <i className="fas fa-edit"></i>
              </button>
              {/* <!-- Modal Edit Account--> */}
              <div
                className="modal fade"
                id="modalUpdate"
                tabIndex="-1"
                aria-labelledby="exampleModalLabel"
                aria-hidden="true"
              >
                <div className="modal-dialog modal-dialog-centered">
                  <div className="modal-content">
                    <div className="modal-header">
                      <h5 className="modal-title" id="exampleModalLabel">
                        Edit Account
                      </h5>
                      <button
                        type="button"
                        className="close"
                        data-dismiss="modal"
                        aria-label="Close"
                      >
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div className="modal-body">
                      <div>
                        {/* {this.state.notif ? (
                          <div class="alert alert-primary" role="alert">
                            Selamat, anda sudah menjadi Manager
                          </div>
                        ) : (
                          ""
                        )} */}

                        <div className="row">
                          <div className="col">
                            <div className="form-group">
                              <label htmlFor="nama">Nama Lengkap</label>
                              <input
                                type="text"
                                className="form-control"
                                id="nama"
                                name="name"
                                onChange={this.handleFormChange}
                                required
                                autoFocus
                              />
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col">
                            <div className="form-group">
                              <label htmlFor="email-1">Email address 1</label>
                              <input
                                type="email"
                                className="form-control"
                                id="email-1"
                                name="email_1"
                                onChange={this.handleFormChange}
                                required
                              />
                            </div>
                          </div>
                          <div className="col">
                            <div className="form-group">
                              <label htmlFor="email-2">Email address 2</label>
                              <input
                                type="email"
                                className="form-control"
                                id="email-2"
                                name="email_2"
                                onChange={this.handleFormChange}
                                required
                              />
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col">
                            <div className="form-group">
                              <label htmlFor="nomor-telepon">
                                Nomor Telepon
                              </label>
                              <input
                                type="tel"
                                className="form-control"
                                id="nomor-telepone"
                                pattern="[0-9]{12}"
                                name="phone"
                                onChange={this.handleFormChange}
                                required
                              />
                              <small>Format 12 digit: 08xxxxxxxxxx</small>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="modal-footer">
                      <button
                        type="button"
                        className="btn btn-secondary"
                        data-dismiss="modal"
                      >
                        Close
                      </button>
                      <button type="button" className="btn btn-primary">
                        Save changes
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container">
          <h4>Kerjasama dengan PBA</h4>
          <table className="table table-bordered table-hover table-sm mt-3">
            <thead>
              <tr className="table-primary text-center">
                <th scope="col">No.</th>
                <th scope="col">Nama</th>
                <th scope="col">Telepon</th>
                <th scope="col">Kantor Cabang</th>
                <th scope="col">Email</th>
                <th scope="col">Ket</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Aso</td>
                <td>(044) 555226</td>
                <td>
                  Kantor Cabang Pembantu BRI, Jl. Urip Sumoharjo No. 17,
                  Makassar
                </td>
                <td>aso@gmail.com</td>
                <td>
                  <a href="/">See details</a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </>
    );
  }
}
