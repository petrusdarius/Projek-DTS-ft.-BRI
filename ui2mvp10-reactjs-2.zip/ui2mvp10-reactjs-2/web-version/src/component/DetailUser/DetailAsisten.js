import React, { Component } from "react";
import { Link } from "react-router-dom";
import Button from "../Button/Button";
import Axios from "axios";

export default class DetailCustomer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      detailPba: [],
    };
  }
  componentDidMount() {
    const id = this.props.match.params.id_asisten;
    console.log(id);
    Axios.get("https://5fb8593e2f145f0016c3c527.mockapi.io/PBA/" + id).then(
      (response) => {
        // console.log(response);
        this.setState({
          detailPba: response.data,
        });
      }
    );
  }
  render() {
    const { detailPba } = this.state;
    return (
      <>
        <nav aria-label="breadcrumb">
          <div className="container">
            <ol className="breadcrumb bg-white mb-0">
              <li className="breadcrumb-item">
                <Link to="/admin-pba">PBA List</Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                {detailPba.name}
              </li>
            </ol>
          </div>
        </nav>

        <div className="jumbotron py-5">
          <div className="container">
            <h1 className="display-4 text-center">{detailPba.name}</h1>
            <hr className="my-4" />

            <div className="mx-auto" style={{ width: 700 }}>
              <p className="lead text-center font-weight-bold">Biodata</p>
              <table
                style={{
                  minWidth: "1000px",
                  margin: "auto",
                  lineHeight: 3,
                }}
              >
                <tbody>
                  <tr>
                    <td>Role</td>
                    <td>: Personal Business Asistant</td>
                  </tr>
                  <tr>
                    <td>Kantor Cabang</td>
                    <td>
                      : {detailPba.kacab}, {detailPba.alamat}
                    </td>
                  </tr>
                  <tr>
                    <td>Email</td>
                    <td>: {detailPba.email}</td>
                  </tr>
                  <tr>
                    <td>Nomor Telpon</td>
                    <td>: {detailPba.phone}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="text-center mt-2">
              <Button
                classes={"btn btn-success btn-lg m-2"}
                action={"Enable"}
              />
              <Button
                classes={"btn btn-danger btn-lg m-2"}
                action={"Disable"}
              />
              {/* <!-- Button Change Password --> */}
              <button
                type="button"
                className="btn btn-primary btn-lg m-2"
                data-toggle="modal"
                data-target="#modalEdit"
              >
                <i className="fas fa-cogs"></i>
              </button>
              {/* <!-- Modal Change Password --> */}
              <div
                className="modal fade"
                id="modalEdit"
                tabIndex="-1"
                aria-labelledby="exampleModalLabel"
                aria-hidden="true"
              >
                <div className="modal-dialog modal-dialog-centered">
                  <div className="modal-content">
                    <div className="modal-header">
                      <h5 className="modal-title" id="exampleModalLabel">
                        Change Password
                      </h5>
                      <button
                        type="button"
                        className="close"
                        data-dismiss="modal"
                        aria-label="Close"
                      >
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div className="modal-body">
                      <form action="">
                        <div className="row">
                          <div className="col">
                            <div className="form-group text-left">
                              <label htmlFor="password-baru">
                                Password Baru
                              </label>
                              <input
                                type="password"
                                className="form-control"
                                id="password-baru"
                                required
                              />
                            </div>
                          </div>

                          <div className="col">
                            <div className="form-group text-left">
                              <label htmlFor="co-password">
                                Confirm Password
                              </label>
                              <input
                                type="password"
                                className="form-control"
                                id="co-password"
                                required
                              />
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                    <div className="modal-footer">
                      <button
                        type="button"
                        className="btn btn-secondary"
                        data-dismiss="modal"
                      >
                        Close
                      </button>
                      <button type="button" className="btn btn-primary">
                        Save changes
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              {/* <!-- Button Edit Account--> */}
              <button
                type="button"
                className="btn btn-primary btn-lg m-2"
                data-toggle="modal"
                data-target="#modalUpdate"
              >
                <i className="fas fa-edit"></i>
              </button>
              {/* <!-- Modal Edit Account--> */}
              <div
                className="modal fade"
                id="modalUpdate"
                tabIndex="-1"
                aria-labelledby="exampleModalLabel"
                aria-hidden="true"
              >
                <div className="modal-dialog modal-dialog-centered">
                  <div className="modal-content">
                    <div className="modal-header">
                      <h5 className="modal-title" id="exampleModalLabel">
                        Edit Account
                      </h5>
                      <button
                        type="button"
                        className="close"
                        data-dismiss="modal"
                        aria-label="Close"
                      >
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div className="modal-body">
                      <div>
                        {/* {this.state.notif ? (
                          <div class="alert alert-primary" role="alert">
                            Selamat, anda sudah menjadi Manager
                          </div>
                        ) : (
                          ""
                        )} */}
                        <div className="row">
                          <div className="col">
                            <div className="form-group">
                              <label htmlFor="nama">Nama Lengkap</label>
                              <input
                                type="text"
                                className="form-control"
                                id="nama"
                                name="name"
                                onChange={this.handleFormChange}
                                required
                                autoFocus
                              />
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col">
                            <div className="form-group">
                              <label htmlFor="email">Email</label>
                              <input
                                type="email"
                                className="form-control"
                                id="email"
                                name="email"
                                onChange={this.handleFormChange}
                                required
                              />
                            </div>
                          </div>
                          <div className="col">
                            <div className="form-group">
                              <label htmlFor="nomor-telepon">
                                Nomor Telepon
                              </label>
                              <input
                                type="tel"
                                className="form-control"
                                id="nomor-telepone"
                                pattern="[0-9]{12}"
                                name="phone"
                                onChange={this.handleFormChange}
                                required
                              />
                              <small>Format 12 digit: 08xxxxxxxxxx</small>
                            </div>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col">
                            <div className="form-group">
                              <label htmlFor="cabang">Kantor Cabang</label>
                              <select
                                className="form-control"
                                id="cabang"
                                name="cabang"
                                onChange={this.handleFormChange}
                              >
                                <option selected>Pilih Kantor Cabang</option>
                                <option>Bunga Api</option>
                                <option>Bunga Air</option>
                                <option>Bunga Indah</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="modal-footer">
                      <button
                        type="button"
                        className="btn btn-secondary"
                        data-dismiss="modal"
                      >
                        Close
                      </button>
                      <button type="button" className="btn btn-primary">
                        Save changes
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container">
          <h4>Kerjasama dengan PCU</h4>
          <table className="table table-bordered table-hover table-sm mt-3">
            <thead>
              <tr className="table-primary text-center">
                <th scope="col">No.</th>
                <th scope="col">Nama</th>
                <th scope="col">Telepon</th>
                {/* <th scope="col">Alamat</th> */}
                <th scope="col">Email 1</th>
                <th scope="col">Email 2</th>
                <th scope="col">Ket</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Kristin Wilson</td>
                <td>(0411) 521897</td>
                {/* <td>Jl. Urip Sumoharjo, Kota Makassar, Sulawesi Selatan</td> */}
                <td>kristin@gmail.com</td>
                <td>kristin@gmail.com</td>
                <td>
                  <Link to="/id-customer">See details</Link>
                </td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Darlene Robertson</td>
                <td>(022) 431291</td>
                {/* <td>Jl. Kemerdekaan, Kota Jakarta</td> */}
                <td>robertson@gmail.com</td>
                <td>robertson@gmail.com</td>
                <td>
                  <a href="/">See details</a>
                </td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Markonah</td>
                <td>(022) 230877</td>
                {/* <td>BTN Mapala No. 11, Kota Surabaya</td> */}
                <td>konaah@yahoo.com</td>
                <td>konaah@yahoo.com</td>
                <td>
                  <a href="/">See details</a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </>
    );
  }
}
