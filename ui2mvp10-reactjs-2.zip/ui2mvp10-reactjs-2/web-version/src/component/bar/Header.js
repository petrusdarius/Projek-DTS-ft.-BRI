import React, { Component } from 'react';

class Header extends Component {
    render() {
        return (
            <nav className='navbar navbar-light bg-light'>
                <div className='row col-12 d-flex justify-content-center text-white'>
                    <span className='h3'>Tambah User</span>
                </div>

            </nav>
        )
    }
}

export default Header;