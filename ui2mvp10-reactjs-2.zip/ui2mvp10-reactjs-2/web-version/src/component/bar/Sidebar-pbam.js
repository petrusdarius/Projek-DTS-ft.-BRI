// SideBar.js

import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import PBARating from "../pages/PBAM/pba-rating";
import ListPBA from "../pages/PBAM/listPBA";
import Dashboard from "../Manager/Manager";
import DailyReport from "../pages/PBAM/dailyReport";
import DetailReport from "../pages/PBAM/detailReport";
import PBAdetail from "../pages/PBAM/detailPBA";
import SetupPCu from "../pages/PBAM/setupPCu";
// import RegistrationForm from '../pages/PBAM/addUser';

class SideBarManager extends Component {
  render() {
    return (
      <div>
        <div className="d-flex" style={{ marginRight: "-5%" }} id="wrapper">
          {/* sidebar */}
          <div
            className="bg-dark border-right text-center"
            style={{position: "fixed" }}
            id="sidebar-wrapper"
          >
            <div className="sidebar-heading">
              <i
                className="fas fa-user-circle fa-4x"
                style={{
                  textAlign: "center",
                  width: "100%",
                  color: "#f6f6f6",
                  marginTop: "20px",
                }}
              ></i>
              <p style={{ color: "white" }}>Admin Brimo</p>
            </div>

            <div className="list-group list-group-flush">
              {/* list PBA */}
              <div className="sidebar-list sidebar-PBA-list">
                <a
                  href="/sidebarManager/listPBA"
                  class="list-group-item list-group-item-action bg-dark"
                >
                  <i
                    class="fas fa-user-friends fa-3x"
                    style={{
                      textAlign: "center",
                      width: "100%",
                      color: "orange",
                    }}
                  ></i>
                  <p style={{ color: "white" }}>Assistant List</p>
                </a>
              </div>

              {/* pba-rating */}
              <div className="sidebar-list sidebar-pba-rating">
                <a
                  href="/sidebarManager/pba-rating"
                  class="list-group-item list-group-item-action bg-dark"
                >
                  <i
                    class="fas fa-star-half-alt fa-3x"
                    style={{
                      textAlign: "center",
                      width: "100%",
                      color: "green",
                    }}
                  ></i>
                  <p style={{ color: "white" }}>PBA Rating</p>
                </a>
              </div>

              {/* Daily Report */}
              <div className="sidebar-list sidebar-daily-report">
                <a
                  href="/sidebarManager/daily-report"
                  class="list-group-item list-group-item-action bg-dark"
                >
                  <i
                    class="fas fa-file-alt fa-3x"
                    style={{
                      textAlign: "center",
                      width: "100%",
                      color: "#f05454",
                    }}
                  ></i>
                  <p style={{ color: "white" }}>Daily Report</p>
                </a>
              </div>

              {/* Set PCu */}
              <div className="sidebar-list sidebar-set-pcu">
                <a
                  href="/sidebarManager/set-pcu"
                  class="list-group-item list-group-item-action bg-dark"
                >
                  <i
                    class="fas fa-users-cog fa-3x"
                    style={{
                      textAlign: "center",
                      width: "100%",
                      color: "#7579e7",
                    }}
                  ></i>
                  <p style={{ color: "white" }}>Set PCu</p>
                </a>
              </div>
              {/* Log out */}
              <div
                className="sidebar-list PBAM-logout"
                style={{ marginTop: "40%" }}
              >
                <a
                  href="/"
                  class="list-group-item list-group-item-action bg-dark"
                >
                  <i
                    class="fas fa-sign-out-alt fa-2x"
                    style={{ color: "whitesmoke" }}
                  ></i>
                  <p style={{ color: "white" }}>Log Out</p>
                </a>
              </div>
            </div>
          </div>
          {/* end sidebar */}

          <Router>
            <Switch>
              {/* <Route path='/sidebar/addUser'>
                        <RegistrationForm />
                        </Route> */}

              <Route path="/sidebarManager/set-pcu">
                <SetupPCu />
              </Route>

              <Route path="/sidebarManager/daily-report/detailReport/:id_report" component={DetailReport}/>

               <Route path='/sidebarManager/listPBA/detailPBA/:id_detailpba' component={PBAdetail}/>

              <Route path="/sidebarManager/listPBA">
                <ListPBA />
              </Route>

              <Route path="/sidebarManager/daily-report">
                <DailyReport />
              </Route>

              <Route path="/sidebarManager/pba-rating">
                <PBARating />
              </Route>

              <Route path="/sidebarManager">
                <Dashboard />
              </Route>
            </Switch>
          </Router>
        </div>
      </div>
    );
  }
}
export default SideBarManager;
