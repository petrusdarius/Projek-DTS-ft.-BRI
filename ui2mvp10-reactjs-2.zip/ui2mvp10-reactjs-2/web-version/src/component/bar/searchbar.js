import React, {useEffect, useState} from 'react';
import {useCombobox} from 'downshift';
import {Input} from 'antd';

function searchbar() {
    const [inputItems, setInputItems] = useState({})
    const[users, setUsers] = useState({})
    const [single, setSingleUser] = useState('')

    useEffect(()=> {
        fetch('https://5fb8593e2f145f0016c3c527.mockapi.io/PBA')
        .then((response) => response.json())
        .then((data) => setUsers(data))
    }, [])
    return(
        <div className='searchbar'>

        </div>
    )
}
export default searchbar