import React, { Component } from "react";

class Dashboard extends Component {
  render() {
    return (
      <div className="container">
        <div class="card mb-3">
          <div class="row no-gutters bg-light">
            <div class="col-md-2">
              <img
                src="https://play-lh.googleusercontent.com/uGyf__KzefsdsdlRZY1MfLx5frFGZ6uB9q9PWLS8c7a95aEuOLfiIuh5qEowtH0asA"
                class="card-img"
                alt="..."
              />
            </div>
            <div class="col-md-8">
              <div class="card-body text-center">
                <h1 class="card-title">Welcome To the Dashboard</h1>
                <h3 class="card-text">Have a Nice work today :)</h3>
              </div>
            </div>
          </div>
        </div>

        {/* bawahnya */}
        <div class="row">
          {/* list PBA */}
          <div class="col-sm-4 offset-sm-1" style={{ marginTop: "20px" }}>
            <div class="card">
              <a
                href="/sidebarManager/listPBA"
                class="list-group-item list-group-item-action"
                style={{ backgroundColor: "#0f4c75" }}
              >
                <i
                  class="fas fa-user-friends fa-5x card-img-top"
                  style={{
                    textAlign: "center",
                    width: "100%",
                    color: "orange",
                  }}
                ></i>
                <div class="card-body">
                  <h5 class="card-title text-center" style={{ color: "white" }}>
                    Assistant list
                  </h5>
                  {/* <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> */}
                  {/* <a href="#" class="btn btn-primary">Go somewhere</a> */}
                </div>
              </a>
            </div>
          </div>

          {/* Rating */}
          <div class="col-sm-4 offset-sm-2" style={{ marginTop: "20px" }}>
            <div class="card">
              <a
                href="/sidebarManager/pba-rating"
                class="list-group-item list-group-item-action"
                style={{ backgroundColor: "#0f4c75" }}
              >
                <i
                  class="fas fa-star-half-alt fa-5x"
                  style={{ textAlign: "center", width: "100%", color: "green" }}
                ></i>
                <div class="card-body">
                  <h5 class="card-title text-center" style={{ color: "white" }}>
                    PBA Rating
                  </h5>
                  {/* <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> */}
                  {/* <a href="#" class="btn btn-primary">Go somewhere</a> */}
                </div>
              </a>
            </div>
          </div>

          {/* Report */}
          <div class="col-sm-4 offset-sm-1" style={{ marginTop: "20px" }}>
            <div class="card">
              <a
                href="/sidebarManager/daily-report"
                class="list-group-item list-group-item-action"
                style={{ backgroundColor: "#0f4c75" }}
              >
                <i
                  class="fas fa-file-alt fa-5x"
                  style={{
                    textAlign: "center",
                    width: "100%",
                    color: "#f05454",
                  }}
                ></i>
                <div class="card-body">
                  <h5 class="card-title text-center" style={{ color: "white" }}>
                    Daily Report
                  </h5>
                  {/* <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> */}
                  {/* <a href="#" class="btn btn-primary">Go somewhere</a> */}
                </div>
              </a>
            </div>
          </div>
          <div class="col-sm-4 offset-sm-2" style={{ marginTop: "20px" }}>
            <div class="card">
              <a
                href="/sidebarManager/set-pcu"
                class="list-group-item list-group-item-action"
                style={{ backgroundColor: "#0f4c75" }}
              >
                <i
                  class="fas fa-users-cog fa-5x"
                  style={{
                    textAlign: "center",
                    width: "100%",
                    color: "#7579e7",
                  }}
                ></i>
                <div class="card-body">
                  <h5 class="card-title text-center" style={{ color: "white" }}>
                    Setup PCu
                  </h5>
                  {/* <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> */}
                  {/* <a href="#" class="btn btn-primary">Go somewhere</a> */}
                </div>
              </a>
            </div>
          </div>
        </div>
        {/* end row */}
      </div>
    );
  }
}
export default Dashboard;
