**Digital Talent Scholarship**

_Thematic Academy_

**Aplikasi BRImo untuk Booking Services**

**UI2 MVP10**
- **JIRA GROUP**
[[**UI2 MVP10**]](https://hatta1998.atlassian.net/jira/software/projects/K1MD/boards/1)


- **UI**
[[**UI**]](https://whimsical.com/ui-9RnNGksBA12rn5SWjCu57Z)